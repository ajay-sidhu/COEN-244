#include "ClientRequest.h"
#include <iostream>

// Default constructor
ClientRequest::ClientRequest() {
}

// Parameterized constructor
ClientRequest::ClientRequest(Client c, Car car) {
    client = c;
    requestedCar = car;
}
// Destructor
ClientRequest::~ClientRequest() {
    std::cout << "ClientRequest object deleted." << std::endl;
}


// Setters
void ClientRequest::setClient(Client c)       { client = c; }
void ClientRequest::setRequestedCar(Car car)  { requestedCar = car; }

// Getters
Client ClientRequest::getClient()          const { return client; }
Car ClientRequest::getRequestedCar()       const { return requestedCar; }

// Print
void ClientRequest::printClientRequest() const {
    std::cout << "---Client Request---" << std::endl;
    client.printClient();
    std::cout << "Requested Car Criteria:" << std::endl;
    requestedCar.printCar();
}