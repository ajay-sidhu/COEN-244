#include "SoldCars.h"
#include <iostream>

// Default constructor
SoldCars::SoldCars() { 
}

// Parameterized constructor
SoldCars::SoldCars(Client c, Car car, Date date) {
    client = c;
    this->car = car;
    purchaseDate = date;
}

// Destructor
SoldCars::~SoldCars() {
    std::cout << "SoldCars object deleted." << std::endl;
}

// Setters
void SoldCars::setClient(Client c){
     client = c; 
}
void SoldCars::setCar(Car c){
     car = c; 
}
void SoldCars::setPurchaseDate(Date date){
     purchaseDate = date; 
}

// Getters
Client SoldCars::getClient() const {
     return client; 
}
Car SoldCars::getCar() const {
     return car; 
}
Date SoldCars::getPurchaseDate() const {
     return purchaseDate; 
}

// Print
void SoldCars::printSoldCar() const {
    std::cout << "--- Sold Car Record ---" << std::endl;
    client.printClient();
    car.printCar();
    std::cout << "Purchase Date: ";
    purchaseDate.printDate();
}