#include "date.h"
#include <iostream>

//constructors/destructor
Date::Date(){
    day = 0;
    month = 0;
    year = 0;
}
Date::Date(int d, int m,int y){
    day = d;
    month = m;
    year = y;
}
Date::~Date(){
    std::cout<<" Date Deleted"<<std::endl;
}

//setters
void Date::setMonth(int month){
    this->month = month;
}
void Date::setDay(int day){
    this->day = day;
}
void Date::setYear(int year){
    this->year = year;
}

//getters
int Date::getMonth() const{
    return month;
} 
int Date::getDay() const{
    return day;
}
int Date::getYear() const{
    return year;
}

//print Date
void Date::printDate() const{
    std::cout<<day<<"/"<<month<<"/"<<year<<std::endl;
} 

