#include "client.h"
#include <iostream>

Client::Client(){
 name = "";
}

Client::Client(std::string n, Date dob) {
    name = n;
    birthDate = dob;
}

Client::~Client() {
    std::cout << "Client object deleted." << std::endl;
}

//Setters
void Client::setName(std::string n){
     name = n; 
}
void Client::setBirthDate(Date dob){
     birthDate = dob; 
}

//getters
std::string Client::getName() const {
     return name; 
}
Date Client::getBirthDate() const {
     return birthDate; 
}


//print function
void Client::printClient() const {
    std::cout << "Name: " << name << std::endl;
    std::cout << "Date of Birth: ";
    birthDate.printDate();
}
