#ifndef SOLDCARS_H
#define SOLDCARS_H

#include "client.h"
#include "car.h"
#include "date.h"

class SoldCars {
private:
    Client client;
    Car car;
    Date purchaseDate;

public:
    SoldCars();
    SoldCars(Client, Car, Date);
    ~SoldCars();

    void setClient(Client);
    void setCar(Car);
    void setPurchaseDate(Date);

    Client getClient() const;
    Car getCar() const;
    Date getPurchaseDate() const;

    void printSoldCar() const;
};

#endif
