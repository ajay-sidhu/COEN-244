#include "CarManager.h"
#include <iostream>

CarManager::CarManager() {
    numCars = 0;
    numSold = 0;
    for (int i = 0; i < 1000; i++)
        forSale[i] = nullptr;
    for (int i = 0; i < 200; i++)
        sold[i] = nullptr;
}

CarManager::~CarManager() {
    for (int i = 0; i < numCars; i++) {
        if (forSale[i] != nullptr) {
            delete forSale[i];
            forSale[i] = nullptr;
        }
    }
    for (int i = 0; i < numSold; i++) {
        if (sold[i] != nullptr) {
            delete sold[i];
            sold[i] = nullptr;
        }
    }
    std::cout << "CarManager object deleted." << std::endl;
}

void CarManager::addCar(Car car){
    forSale[numCars] = new Car(car);
    numCars++;
}

SoldCars CarManager::processPurchase(ClientRequest request) {
    int bestIndex = -1;

    for (int i = 0; i < numCars; i++) {
        if (forSale[i]->getModel()     == request.getRequestedCar().getModel()     &&
            forSale[i]->getColor()     == request.getRequestedCar().getColor()     &&
            forSale[i]->getModelYear() >= request.getRequestedCar().getModelYear() &&
            forSale[i]->getPrice()     <= request.getRequestedCar().getPrice()     &&
            forSale[i]->getMileage()   <= request.getRequestedCar().getMileage()) {

            if (bestIndex == -1) {
                bestIndex = i;
            } else {
                if (forSale[i]->getModelYear() > forSale[bestIndex]->getModelYear()) {
                    bestIndex = i;
                } else if (forSale[i]->getModelYear() == forSale[bestIndex]->getModelYear()) {
                    if (forSale[i]->getPrice() < forSale[bestIndex]->getPrice()) {
                        bestIndex = i;
                    } else if (forSale[i]->getPrice() == forSale[bestIndex]->getPrice()) {
                        if (forSale[i]->getMileage() < forSale[bestIndex]->getMileage()) {
                            bestIndex = i;
                        }
                    }
                }
            }
        }
    }

    if (bestIndex == -1) {
        return SoldCars();
    } else {
        SoldCars soldCar(request.getClient(), *forSale[bestIndex], Date());

        sold[numSold] = new SoldCars(soldCar);
        numSold++;

        delete forSale[bestIndex];
        forSale[bestIndex] = forSale[numCars - 1];
        forSale[numCars - 1] = nullptr;
        numCars--;

        return soldCar;
    }
}

std::string CarManager::findCarByClient(std::string name) {
    for (int i = 0; i < numSold; i++) {
        if (sold[i]->getClient().getName() == name)
            return sold[i]->getCar().getSerialNum();
    }
    return "";
}

void CarManager::printInventory() const {
    std::cout << "--- Inventory ---" << std::endl;
    for (int i = 0; i < numCars; i++) {
        forSale[i]->printCar();
        std::cout << std::endl;
    }
}

void CarManager::printSoldClients() const {
    std::cout << "--- Sold Cars ---" << std::endl;
    for (int i = 0; i < numSold; i++) {
        sold[i]->printSoldCar();
        std::cout << std::endl;
    }
}
