#ifndef CLIENTREQUEST_H
#define CLIENTREQUEST_H

#include "client.h"
#include "car.h"

class ClientRequest {
private:
    Client client;
    Car requestedCar;   
public:
    ClientRequest();
    ClientRequest(Client, Car);
    ~ClientRequest();

    void setClient(Client);
    void setRequestedCar(Car);

    Client getClient() const;
    Car getRequestedCar() const;

    void printClientRequest() const;
};

#endif