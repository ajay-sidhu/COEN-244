#ifndef CARMANAGER_H
#define CARMANAGER_H

#include "car.h"
#include "SoldCars.h"
#include "ClientRequest.h"

class CarManager{
private:
Car *forSale[1000];
SoldCars *sold[200];
int numCars;
int numSold;

public:
CarManager();
~CarManager();

    
void addCar(Car car);                             // inserts a car into inventory
SoldCars processPurchase(ClientRequest request);  // processes a client request
std::string findCarByClient(std::string name);    // returns serial number or ""
void printInventory() const;                      // prints all cars for sale
void printSoldClients() const;                    // prints all clients who bought



};

#endif

