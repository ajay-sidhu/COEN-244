#ifndef DATE_H
#define DATE_H

class Date{
private:
int month, day, year;

public:
Date();                           
Date(int, int ,int);
~Date();

//setters
void setMonth(int);                 
void setDay(int);
void setYear(int);

//getters
int getMonth() const;               
int getDay() const;
int getYear() const;

//print Date
void printDate() const;             

};

#endif







