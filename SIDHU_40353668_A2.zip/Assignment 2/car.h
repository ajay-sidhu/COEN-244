#ifndef CAR_H
#define CAR_H

#include <string>

class Car{
private:
std::string model, color, serialNum;
int modelYear, mileage, price;

public:
Car();
Car(std::string, std::string,std::string, int, int, int);
~Car();

//setters
void setModel(std::string);
void setColor(std::string);
void setSerialNum(std::string);
void setModelYear(int);
void setMileage(int);
void setPrice(int);

//getters
std::string getModel() const;
std::string getColor() const;
std::string getSerialNum() const;
int getModelYear() const; 
int getMileage() const;
int getPrice() const;

//print function
void printCar() const;

};


#endif