#include <iostream>
#include "CarManager.h"
#include "ClientRequest.h"

int main() {
    CarManager manager;

    // Add supercars to inventory
    Car c1("Lamborghini Huracan", "Red", "100001", 2020, 45000, 180000);
    Car c2("Lamborghini Huracan", "Red", "100002", 2022, 38000, 210000);
    Car c3("Lamborghini Huracan", "Red", "100003", 2023, 31000, 230000);
    Car c4("Lamborghini Huracan", "Red", "100004", 2023, 28000, 225000);
    Car c5("Lamborghini Huracan", "Red", "100005", 2023, 35000, 225000);
    Car c6("Ferrari 488", "Blue", "100006", 2019, 52000, 195000);
    Car c7("Ferrari 488", "Blue", "100007", 2021, 41000, 215000);
    Car c8("Bugatti Chiron", "Black", "100008", 2020, 22000, 290000);

    manager.addCar(c1);
    manager.addCar(c2);
    manager.addCar(c3);
    manager.addCar(c4);
    manager.addCar(c5);
    manager.addCar(c6);
    manager.addCar(c7);
    manager.addCar(c8);

    // Print inventory before purchases
    std::cout << "=== Inventory Before Purchases ===" << std::endl;
    manager.printInventory();

    // Tony Stark wants a Lamborghini
    Date dob1(29, 5, 1970);
    Client client1("Tony Stark", dob1);
    Car criteria1("Lamborghini Huracan", "Red", "", 2020, 50000, 240000);
    ClientRequest req1(client1, criteria1);

    std::cout << "=== Processing Request 1 ===" << std::endl;
    req1.printClientRequest();
    SoldCars result1 = manager.processPurchase(req1);
    std::cout << "--- Result ---" << std::endl;
    result1.printSoldCar();

    // Natasha Romanoff wants a Ferrari
    Date dob2(3, 11, 1984);
    Client client2("Natasha Romanoff", dob2);
    Car criteria2("Ferrari 488", "Blue", "", 2019, 60000, 220000);
    ClientRequest req2(client2, criteria2);

    std::cout << "=== Processing Request 2 ===" << std::endl;
    req2.printClientRequest();
    SoldCars result2 = manager.processPurchase(req2);
    std::cout << "--- Result ---" << std::endl;
    result2.printSoldCar();

    // Thor wants a Bugatti but no match
    Date dob3(15, 8, 1500);
    Client client3("Thor Odinson", dob3);
    Car criteria3("Bugatti Chiron", "Black", "", 2022, 20000, 300000);
    ClientRequest req3(client3, criteria3);

    std::cout << "=== Processing Request 3 (no match expected) ===" << std::endl;
    req3.printClientRequest();
    SoldCars result3 = manager.processPurchase(req3);
    std::cout << "--- Result ---" << std::endl;
    result3.printSoldCar();

    // Print remaining inventory
    std::cout << "=== Inventory After Purchases ===" << std::endl;
    manager.printInventory();

    // Print all sold clients
    std::cout << "=== Clients Who Purchased Cars ===" << std::endl;
    manager.printSoldClients();

    // Find car by client name
    std::cout << "=== Finding Cars By Client ===" << std::endl;
    std::string serial1 = manager.findCarByClient("Tony Stark");
    std::cout << "Tony Stark's car serial: " << serial1 << std::endl;

    std::string serial2 = manager.findCarByClient("Natasha Romanoff");
    std::cout << "Natasha Romanoff's car serial: " << serial2 << std::endl;

    std::string serial3 = manager.findCarByClient("Thor Odinson");
    if (serial3 == "")
        std::cout << "Thor Odinson has not purchased a car." << std::endl;
    else
        std::cout << "Thor Odinson's car serial: " << serial3 << std::endl;

    return 0;
}
