#ifndef CLIENT_H
#define CLIENT_H

#include <string>
#include "date.h"

class Client{
private:
std::string name;
Date birthDate;

public:
Client();
Client(std::string, Date);
~Client();

void setName(std::string);
void setBirthDate(Date);

std::string getName() const;
Date getBirthDate() const;

void printClient() const;
};




#endif