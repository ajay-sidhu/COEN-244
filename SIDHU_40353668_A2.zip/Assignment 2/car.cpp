#include "car.h"
#include <iostream>

//constructors 
Car::Car(){
 model = "";
 color = "";
 serialNum = "";
 modelYear = 0;
 mileage = 0;
 price =0;
}

Car::Car(std::string mod,std::string col,std::string serial,int modYear, int miles, int cost){
 model = mod;
 color = col;
 serialNum = serial;
 modelYear = modYear;
 mileage = miles;
 price = cost;
}

Car::~Car() {
    std::cout << "Car object deleted." << std::endl;
}

// Setters
void Car::setModel(std::string mod){
    model = mod; 
}
void Car::setColor(std::string col){
     color = col; 
    }
void Car::setSerialNum(std::string serial){ 
    serialNum = serial; 
}
void Car::setModelYear(int year){
     modelYear = year; 
    }
void Car::setMileage(int miles){
     mileage = miles; 
}
void Car::setPrice(int cost){
     price = cost; 
}

//getters
std::string Car::getModel()const{
    return model;
}

std::string Car::getColor()const { 
    return color; 
}
std::string Car::getSerialNum() const{ 
    return serialNum; 
}
int Car::getModelYear()const { return modelYear;
}

int Car::getMileage()const { 
    return mileage; 
}
int Car::getPrice()const { 
    return price; 
}

// Print function
void Car::printCar() const {
    std::cout << "Model:      " << model     << std::endl;
    std::cout << "Color:      " << color     << std::endl;
    std::cout << "Serial #:   " << serialNum << std::endl;
    std::cout << "Model Year: " << modelYear << std::endl;
    std::cout << "Mileage:    " << mileage   << " kms" << std::endl;
    std::cout << "Price: $" << price<< std::endl;
}