#include "parttimeprofessor.h"
#include <iostream>

parttimeprofessor::parttimeprofessor() : professor() {
    numCourses = 0;
    for (int i = 0; i < 3; i++) {
        courses[i] = nullptr;
    }
}

parttimeprofessor::parttimeprofessor(std::string name, date dob, date hireDate)
    : professor(name, dob, hireDate) {
    numCourses = 0;
    for (int i = 0; i < 3; i++) {
        courses[i] = nullptr;
    }
}

parttimeprofessor::~parttimeprofessor() {
    std::cout << "PartTimeProfessor has been deleted" << std::endl;
}

int parttimeprofessor::getNumCourses() const {
    return numCourses;
}

bool parttimeprofessor::addCourse(course* newCourse) {
    if (numCourses >= 3 || newCourse == nullptr) {
        return false;
    }

    for (int i = 0; i < numCourses; i++) {
        if (courses[i] != nullptr && courses[i]->getCourseNum() == newCourse->getCourseNum()) {
            return false;
        }
    }

    courses[numCourses] = newCourse;
    numCourses++;
    return true;
}

void parttimeprofessor::printPerson() const {
    professor::printPerson();
    std::cout << "Professor Type: Part-Time Professor" << std::endl;
    std::cout << "Number of Teaching Courses: " << numCourses << std::endl;
    std::cout << "Teaching Courses:" << std::endl;

    for (int i = 0; i < numCourses; i++) {
        if (courses[i] != nullptr) {
            courses[i]->printCourse();
        }
    }
}
