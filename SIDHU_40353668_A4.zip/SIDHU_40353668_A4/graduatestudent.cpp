#include "graduatestudent.h"
#include <iostream>

graduatestudent::graduatestudent() : student() {
    numCourses = 0;
    for (int i = 0; i < 2; i++) {
        courses[i] = nullptr;
    }
}

graduatestudent::graduatestudent(std::string name, date dob, date enrollDate)
    : student(name, dob, enrollDate) {
    numCourses = 0;
    for (int i = 0; i < 2; i++) {
        courses[i] = nullptr;
    }
}

graduatestudent::~graduatestudent() {
    std::cout << "GraduateStudent has been deleted" << std::endl;
}

int graduatestudent::getNumCourses() const {
    return numCourses;
}

bool graduatestudent::addCourse(course* newCourse) {
    if (numCourses >= 2 || newCourse == nullptr) {
        return false;
    }

    for (int i = 0; i < numCourses; i++) {
        if (courses[i] != nullptr && courses[i]->getCourseNum() == newCourse->getCourseNum()) {
            return false;
        }
    }

    courses[numCourses] = newCourse;
    numCourses++;
    return true;
}

bool graduatestudent::dropCourse(int courseNum) {
    for (int i = 0; i < numCourses; i++) {
        if (courses[i] != nullptr && courses[i]->getCourseNum() == courseNum) {
            for (int j = i; j < numCourses - 1; j++) {
                courses[j] = courses[j + 1];
            }
            courses[numCourses - 1] = nullptr;
            numCourses--;
            return true;
        }
    }
    return false;
}

void graduatestudent::printPerson() const {
    student::printPerson();
    std::cout << "Student Type: Graduate Student" << std::endl;
    std::cout << "Number of Courses: " << numCourses << std::endl;
    std::cout << "Registered Courses:" << std::endl;

    for (int i = 0; i < numCourses; i++) {
        if (courses[i] != nullptr) {
            courses[i]->printCourse();
        }
    }
}
