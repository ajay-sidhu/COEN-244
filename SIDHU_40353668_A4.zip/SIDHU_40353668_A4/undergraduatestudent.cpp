#include "undergraduatestudent.h"
#include <iostream>

undergraduatestudent::undergraduatestudent() : student() {
    numCourses = 0;
    for (int i = 0; i < 4; i++) {
        courses[i] = nullptr;
    }
}

undergraduatestudent::undergraduatestudent(std::string name, date dob, date enrollDate)
    : student(name, dob, enrollDate) {
    numCourses = 0;
    for (int i = 0; i < 4; i++) {
        courses[i] = nullptr;
    }
}

undergraduatestudent::~undergraduatestudent() {
    std::cout << "UndergraduateStudent has been deleted" << std::endl;
}

int undergraduatestudent::getNumCourses() const {
    return numCourses;
}

bool undergraduatestudent::addCourse(course* newCourse) {
    if (numCourses >= 4 || newCourse == nullptr) {
        return false;
    }

    for (int i = 0; i < numCourses; i++) {
        if (courses[i] != nullptr && courses[i]->getCourseNum() == newCourse->getCourseNum()) {
            return false;
        }
    }

    courses[numCourses] = newCourse;
    numCourses++;
    return true;
}

bool undergraduatestudent::dropCourse(int courseNum) {
    for (int i = 0; i < numCourses; i++) {
        if (courses[i] != nullptr && courses[i]->getCourseNum() == courseNum) {
            for (int j = i; j < numCourses - 1; j++) {
                courses[j] = courses[j + 1];
            }
            courses[numCourses - 1] = nullptr;
            numCourses--;
            return true;
        }
    }
    return false;
}

void undergraduatestudent::printPerson() const {
    student::printPerson();
    std::cout << "Student Type: Undergraduate Student" << std::endl;
    std::cout << "Number of Courses: " << numCourses << std::endl;
    std::cout << "Registered Courses:" << std::endl;

    for (int i = 0; i < numCourses; i++) {
        if (courses[i] != nullptr) {
            courses[i]->printCourse();
        }
    }
}
