#include "professor.h"
#include <iostream>

int professor::nextEmployeeID = 2000;

professor::professor() : person() {
    nextEmployeeID++;
    employeeID = nextEmployeeID;
    employmentDate = date();
}

professor::professor(std::string name, date dob, date hireDate) : person(name, dob) {
    nextEmployeeID++;
    employeeID = nextEmployeeID;
    employmentDate = hireDate;
}

professor::~professor() {
    std::cout << "Professor has been deleted" << std::endl;
}

void professor::setEmploymentDate(date hireDate) {
    employmentDate = hireDate;
}

int professor::getEmployeeID() const {
    return employeeID;
}

date professor::getEmploymentDate() const {
    return employmentDate;
}

int professor::getid() const {
    return employeeID;
}

void professor::printPerson() const {
    person::printPerson();
    std::cout << "Employee ID: " << employeeID << std::endl;
    std::cout << "Employment Date: ";
    employmentDate.printDate();
}
