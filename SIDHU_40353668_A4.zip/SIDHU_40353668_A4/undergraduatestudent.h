#ifndef UNDERGRADUATESTUDENT_H
#define UNDERGRADUATESTUDENT_H

#include "student.h"
#include "course.h"
#include <string>

class undergraduatestudent : public student {
private:
    int numCourses;
    course* courses[4];

public:
    undergraduatestudent();
    undergraduatestudent(std::string, date, date);
    virtual ~undergraduatestudent();

    int getNumCourses() const;
    virtual bool addCourse(course*);
    virtual bool dropCourse(int);
    virtual void printPerson() const;
};

#endif
