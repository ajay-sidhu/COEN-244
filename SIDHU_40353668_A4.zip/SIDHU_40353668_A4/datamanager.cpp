#include "datamanager.h"
#include "graduatestudent.h"
#include "fulltimeprofessor.h"
#include <iostream>

datamanager::datamanager() {
    numStudents = 0;
    numProfessors = 0;
    numCourses = 0;

    for (int i = 0; i < 5000; i++) {
        students[i] = nullptr;
    }
    for (int i = 0; i < 100; i++) {
        professors[i] = nullptr;
    }
    for (int i = 0; i < 200; i++) {
        courses[i] = nullptr;
    }
}

datamanager::~datamanager() {
    for (int i = 0; i < numStudents; i++) {
        delete students[i];
        students[i] = nullptr;
    }
    for (int i = 0; i < numProfessors; i++) {
        delete professors[i];
        professors[i] = nullptr;
    }
    for (int i = 0; i < numCourses; i++) {
        delete courses[i];
        courses[i] = nullptr;
    }

    std::cout << "DataManager has been deleted" << std::endl;
}

student* datamanager::findStudent(int studentID) const {
    for (int i = 0; i < numStudents; i++) {
        if (students[i] != nullptr && students[i]->getid() == studentID) {
            return students[i];
        }
    }
    return nullptr;
}

professor* datamanager::findProfessor(int employeeID) const {
    for (int i = 0; i < numProfessors; i++) {
        if (professors[i] != nullptr && professors[i]->getid() == employeeID) {
            return professors[i];
        }
    }
    return nullptr;
}

courseregistration* datamanager::findCourse(int courseNum) const {
    for (int i = 0; i < numCourses; i++) {
        if (courses[i] != nullptr && courses[i]->getCourseNum() == courseNum) {
            return courses[i];
        }
    }
    return nullptr;
}

bool datamanager::addStudent(student* newStudent) {
    if (numStudents >= 5000 || newStudent == nullptr) {
        return false;
    }

    students[numStudents] = newStudent;
    numStudents++;
    std::cout << "Student " << newStudent->getid() << " enrolled at university." << std::endl;
    return true;
}

bool datamanager::addProfessor(professor* newProfessor) {
    if (numProfessors >= 100 || newProfessor == nullptr) {
        return false;
    }

    professors[numProfessors] = newProfessor;
    numProfessors++;
    std::cout << "Professor " << newProfessor->getid() << " added to university." << std::endl;
    return true;
}

bool datamanager::addCourse(courseregistration* newCourse) {
    if (numCourses >= 200 || newCourse == nullptr) {
        return false;
    }

    courses[numCourses] = newCourse;
    numCourses++;
    std::cout << newCourse->getDepartment() << " " << newCourse->getCourseNum() << " added." << std::endl;
    return true;
}

bool datamanager::removeStudent(int studentID) {
    for (int i = 0; i < numStudents; i++) {
        if (students[i] != nullptr && students[i]->getid() == studentID) {
            delete students[i];

            for (int j = i; j < numStudents - 1; j++) {
                students[j] = students[j + 1];
            }
            students[numStudents - 1] = nullptr;
            numStudents--;
            std::cout << "Student " << studentID << " removed from university." << std::endl;
            return true;
        }
    }
    return false;
}

bool datamanager::removeCourse(int courseNum) {
    for (int i = 0; i < numCourses; i++) {
        if (courses[i] != nullptr && courses[i]->getCourseNum() == courseNum) {
            delete courses[i];

            for (int j = i; j < numCourses - 1; j++) {
                courses[j] = courses[j + 1];
            }
            courses[numCourses - 1] = nullptr;
            numCourses--;
            std::cout << "Course " << courseNum << " removed from course list." << std::endl;
            return true;
        }
    }
    return false;
}

bool datamanager::registerStudentToCourse(int studentID, courseregistration* selectedCourse) {
    student* selectedStudent = findStudent(studentID);

    if (selectedStudent == nullptr || selectedCourse == nullptr) {
        return false;
    }

    if (!selectedCourse->registerStudent(studentID)) {
        return false;
    }

    if (!selectedStudent->addCourse(selectedCourse)) {
        selectedCourse->removeStudent(studentID);
        return false;
    }

    std::cout << "Student " << studentID << " registered to "
              << selectedCourse->getDepartment() << " " << selectedCourse->getCourseNum() << "." << std::endl;
    return true;
}

bool datamanager::dropStudentFromCourse(int studentID, courseregistration* selectedCourse) {
    student* selectedStudent = findStudent(studentID);

    if (selectedStudent == nullptr || selectedCourse == nullptr) {
        return false;
    }

    bool removedFromCourse = selectedCourse->removeStudent(studentID);
    bool removedFromStudent = selectedStudent->dropCourse(selectedCourse->getCourseNum());

    if (removedFromCourse && removedFromStudent) {
        std::cout << "Student " << studentID << " dropped "
                  << selectedCourse->getDepartment() << " " << selectedCourse->getCourseNum() << "." << std::endl;
        return true;
    }

    return false;
}

bool datamanager::isStudentEnrolled(int studentID, courseregistration* selectedCourse) const {
    if (selectedCourse == nullptr) {
        return false;
    }

    return selectedCourse->isStudentRegistered(studentID);
}

bool datamanager::isStudentAtUniversity(int studentID) const {
    return findStudent(studentID) != nullptr;
}

bool datamanager::addSupervisor(int gradStudentID, int professorID) {
    student* selectedStudent = findStudent(gradStudentID);
    professor* selectedProfessor = findProfessor(professorID);

    graduatestudent* grad = dynamic_cast<graduatestudent*>(selectedStudent);
    fulltimeprofessor* fullTime = dynamic_cast<fulltimeprofessor*>(selectedProfessor);

    if (grad == nullptr || fullTime == nullptr) {
        return false;
    }

    if (fullTime->addGraduateStudent(grad)) {
        std::cout << "Professor " << professorID << " is now supervising graduate student "
                  << gradStudentID << "." << std::endl;
        return true;
    }

    return false;
}

void datamanager::printStudents() const {
    std::cout << "\n--- Students ---" << std::endl;
    for (int i = 0; i < numStudents; i++) {
        if (students[i] != nullptr) {
            students[i]->printPerson();
            std::cout << std::endl;
        }
    }
}

void datamanager::printProfessors() const {
    std::cout << "\n--- Professors ---" << std::endl;
    for (int i = 0; i < numProfessors; i++) {
        if (professors[i] != nullptr) {
            professors[i]->printPerson();
            std::cout << std::endl;
        }
    }
}

void datamanager::printCourses() const {
    std::cout << "\n--- Courses ---" << std::endl;
    for (int i = 0; i < numCourses; i++) {
        if (courses[i] != nullptr) {
            courses[i]->printCourseRegistration();
            std::cout << std::endl;
        }
    }
}
