#include "fulltimeprofessor.h"
#include <iostream>

fulltimeprofessor::fulltimeprofessor() : professor() {
    numCourses = 0;
    numSupervisedStudents = 0;

    for (int i = 0; i < 2; i++) {
        courses[i] = nullptr;
    }
    for (int i = 0; i < 10; i++) {
        supervisedStudents[i] = nullptr;
    }
}

fulltimeprofessor::fulltimeprofessor(std::string name, date dob, date hireDate)
    : professor(name, dob, hireDate) {
    numCourses = 0;
    numSupervisedStudents = 0;

    for (int i = 0; i < 2; i++) {
        courses[i] = nullptr;
    }
    for (int i = 0; i < 10; i++) {
        supervisedStudents[i] = nullptr;
    }
}

fulltimeprofessor::~fulltimeprofessor() {
    std::cout << "FullTimeProfessor has been deleted" << std::endl;
}

int fulltimeprofessor::getNumCourses() const {
    return numCourses;
}

int fulltimeprofessor::getNumSupervisedStudents() const {
    return numSupervisedStudents;
}

bool fulltimeprofessor::addCourse(course* newCourse) {
    if (numCourses >= 2 || newCourse == nullptr) {
        return false;
    }

    for (int i = 0; i < numCourses; i++) {
        if (courses[i] != nullptr && courses[i]->getCourseNum() == newCourse->getCourseNum()) {
            return false;
        }
    }

    courses[numCourses] = newCourse;
    numCourses++;
    return true;
}

bool fulltimeprofessor::addGraduateStudent(graduatestudent* gradStudent) {
    if (numSupervisedStudents >= 10 || gradStudent == nullptr) {
        return false;
    }

    for (int i = 0; i < numSupervisedStudents; i++) {
        if (supervisedStudents[i] != nullptr && supervisedStudents[i]->getid() == gradStudent->getid()) {
            return false;
        }
    }

    supervisedStudents[numSupervisedStudents] = gradStudent;
    numSupervisedStudents++;
    return true;
}

void fulltimeprofessor::printPerson() const {
    professor::printPerson();
    std::cout << "Professor Type: Full-Time Professor" << std::endl;
    std::cout << "Number of Teaching Courses: " << numCourses << std::endl;
    std::cout << "Teaching Courses:" << std::endl;

    for (int i = 0; i < numCourses; i++) {
        if (courses[i] != nullptr) {
            courses[i]->printCourse();
        }
    }

    std::cout << "Number of Supervised Graduate Students: " << numSupervisedStudents << std::endl;
    for (int i = 0; i < numSupervisedStudents; i++) {
        if (supervisedStudents[i] != nullptr) {
            std::cout << "Graduate Student ID: " << supervisedStudents[i]->getid() << std::endl;
        }
    }
}
