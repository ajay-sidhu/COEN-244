#include <iostream>
#include "date.h"
#include "course.h"
#include "courseregistration.h"
#include "person.h"
#include "student.h"
#include "undergraduatestudent.h"
#include "graduatestudent.h"
#include "professor.h"
#include "fulltimeprofessor.h"
#include "parttimeprofessor.h"
#include "datamanager.h"

int main() {
    datamanager university;

    // Create students dynamically
    undergraduatestudent* student1 = new undergraduatestudent("John Smith", date(10, 5, 2004), date(1, 9, 2026));
    graduatestudent* student2 = new graduatestudent("Sara Brown", date(12, 3, 2000), date(1, 9, 2026));

    // Create professors dynamically
    fulltimeprofessor* professor1 = new fulltimeprofessor("Dr. Ali", date(20, 1, 1975), date(15, 8, 2018));
    parttimeprofessor* professor2 = new parttimeprofessor("Dr. Chen", date(2, 11, 1980), date(15, 8, 2022));

    // Add students and professors to university
    university.addStudent(student1);
    university.addStudent(student2);
    university.addProfessor(professor1);
    university.addProfessor(professor2);

    // Create courses dynamically
    courseregistration* course1 = new courseregistration("COEN", 244, "Programming Methodology", "Dr. Ali", 3);
    courseregistration* course2 = new courseregistration("MATH", 204, "Linear Algebra", "Dr. Chen", 2);
    courseregistration* course3 = new courseregistration("ELEC", 242, "Circuit Analysis", "Dr. Ali", 2);

    university.addCourse(course1);
    university.addCourse(course2);
    university.addCourse(course3);

    // Assign courses to professors
    professor1->addCourse(course1);
    professor1->addCourse(course3);
    professor2->addCourse(course2);

    // Register students to courses
    university.registerStudentToCourse(student1->getid(), course1);
    university.registerStudentToCourse(student1->getid(), course2);
    university.registerStudentToCourse(student2->getid(), course1);
    university.registerStudentToCourse(student2->getid(), course3);

    // Drop a student from a course
    university.dropStudentFromCourse(student1->getid(), course2);

    // Check enrollment
    if (university.isStudentEnrolled(student1->getid(), course1)) {
        std::cout << "Student " << student1->getid() << " is enrolled in COEN 244." << std::endl;
    }

    if (university.isStudentAtUniversity(student2->getid())) {
        std::cout << "Student " << student2->getid() << " is enrolled at the university." << std::endl;
    }

    // Add professor as supervisor of graduate student
    university.addSupervisor(student2->getid(), professor1->getid());

    // Show polymorphism using Person pointers
    std::cout << "\n--- Polymorphism Demonstration ---" << std::endl;
    person* people[4];
    people[0] = student1;
    people[1] = student2;
    people[2] = professor1;
    people[3] = professor2;

    for (int i = 0; i < 4; i++) {
        people[i]->printPerson();
        std::cout << "ID using getid(): " << people[i]->getid() << std::endl;
        std::cout << std::endl;
    }

    university.printStudents();
    university.printProfessors();
    university.printCourses();

    // No delete here. DataManager deletes all dynamic objects in its destructor.
    return 0;
}
