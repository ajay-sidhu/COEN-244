#ifndef STUDENT_H
#define STUDENT_H

#include "person.h"
#include "date.h"
#include "course.h"
#include <string>

class student : public person {
private:
    static int nextStudentID;
    int studentID;
    date enrollmentDate;

public:
    student();
    student(std::string, date, date);
    virtual ~student();

    void setEnrollmentDate(date);

    int getStudentID() const;
    date getEnrollmentDate() const;

    virtual int getid() const;
    virtual bool addCourse(course*) = 0;
    virtual bool dropCourse(int) = 0;
    virtual void printPerson() const;
};

#endif
