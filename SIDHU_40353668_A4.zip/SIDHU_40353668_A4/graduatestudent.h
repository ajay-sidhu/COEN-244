#ifndef GRADUATESTUDENT_H
#define GRADUATESTUDENT_H

#include "student.h"
#include "course.h"
#include <string>

class graduatestudent : public student {
private:
    int numCourses;
    course* courses[2];

public:
    graduatestudent();
    graduatestudent(std::string, date, date);
    virtual ~graduatestudent();

    int getNumCourses() const;
    virtual bool addCourse(course*);
    virtual bool dropCourse(int);
    virtual void printPerson() const;
};

#endif
