#include "student.h"
#include <iostream>

int student::nextStudentID = 1000;

student::student() : person() {
    nextStudentID++;
    studentID = nextStudentID;
    enrollmentDate = date();
}

student::student(std::string name, date dob, date enrollDate) : person(name, dob) {
    nextStudentID++;
    studentID = nextStudentID;
    enrollmentDate = enrollDate;
}

student::~student() {
    std::cout << "Student has been deleted" << std::endl;
}

void student::setEnrollmentDate(date enrollDate) {
    enrollmentDate = enrollDate;
}

int student::getStudentID() const {
    return studentID;
}

date student::getEnrollmentDate() const {
    return enrollmentDate;
}

int student::getid() const {
    return studentID;
}

void student::printPerson() const {
    person::printPerson();
    std::cout << "Student ID: " << studentID << std::endl;
    std::cout << "Enrollment Date: ";
    enrollmentDate.printDate();
}
