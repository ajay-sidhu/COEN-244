#ifndef PROFESSOR_H
#define PROFESSOR_H

#include "person.h"
#include "date.h"
#include "course.h"
#include <string>

class professor : public person {
private:
    static int nextEmployeeID;
    int employeeID;
    date employmentDate;

public:
    professor();
    professor(std::string, date, date);
    virtual ~professor();

    void setEmploymentDate(date);

    int getEmployeeID() const;
    date getEmploymentDate() const;

    virtual int getid() const;
    virtual bool addCourse(course*) = 0;
    virtual void printPerson() const;
};

#endif
