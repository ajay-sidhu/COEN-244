#ifndef DATE_H
#define DATE_H

#include <ostream>

class date {
private:
    int month;
    int day;
    int year;

public:
    date();
    date(int, int, int);
    ~date();

    void setMonth(int);
    void setDay(int);
    void setYear(int);

    int getMonth() const;
    int getDay() const;
    int getYear() const;

    bool operator>(const date&) const;
    friend std::ostream& operator<<(std::ostream&, const date&);

    void printDate() const;
};

#endif
