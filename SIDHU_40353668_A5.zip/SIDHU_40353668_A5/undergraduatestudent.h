#ifndef UNDERGRADUATESTUDENT_H
#define UNDERGRADUATESTUDENT_H

#include "student.h"
#include "course.h"
#include <ostream>
#include <string>

class undergraduatestudent : public student {
private:
    int numCourses;
    course* courses[4];

public:
    undergraduatestudent();
    undergraduatestudent(std::string, date, date);
    undergraduatestudent(std::string, date, date, date);
    virtual ~undergraduatestudent();

    int getNumCourses() const;
    virtual bool addCourse(course*);
    virtual bool dropCourse(course*);
    virtual void printPerson() const;

    friend std::ostream& operator<<(std::ostream&, const undergraduatestudent&);
};

#endif
