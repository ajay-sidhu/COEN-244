#include "person.h"
#include <iostream>

person::person() {
    name = "";
}

person::person(std::string n, date d) {
    name = n;
    dob = d;
}

person::~person() {
    std::cout << "Person was Deleted" << std::endl;
}

void person::setName(std::string name) {
    this->name = name;
}

void person::setDOB(date dob) {
    this->dob = dob;
}

std::string person::getName() const {
    return name;
}

const date& person::getDOB() const {
    return dob;
}

void person::printPerson() const {
    std::cout << "Name: " << name << std::endl;
    std::cout << "DOB: ";
    dob.printDate();
}
