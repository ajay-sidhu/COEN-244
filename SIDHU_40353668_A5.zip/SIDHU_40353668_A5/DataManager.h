#ifndef DATAMANAGER_H
#define DATAMANAGER_H

#include "student.h"
#include "professor.h"
#include "courseregistration.h"
#include <string>

class datamanager {
private:
    int numStudents;
    int numProfessors;
    int numCourses;

    student* students[5000];
    professor* professors[100];
    courseregistration* courses[200];

    student* findStudent(int) const;
    professor* findProfessor(int) const;
    courseregistration* findCourse(const courseregistration*) const;

public:
    datamanager();
    ~datamanager();

    bool addStudent(student*);
    bool addProfessor(professor*);
    bool addCourse(courseregistration*);

    bool removeStudent(int);
    bool removeCourse(courseregistration*);

    bool registerStudentToCourse(int, courseregistration*);
    bool dropStudentFromCourse(int, courseregistration*);
    bool isStudentEnrolled(int, courseregistration*) const;
    bool isStudentAtUniversity(int) const;

    bool addSupervisor(int, int);

    bool saveStudent(std::string, student*);
    void searchStudent(std::string, std::string, int);

    void printStudents() const;
    void printProfessors() const;
    void printCourses() const;
};

#endif
