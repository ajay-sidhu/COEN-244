#ifndef STUDENT_H
#define STUDENT_H

#include "person.h"
#include "date.h"
#include "course.h"
#include <string>

class student : public person {
private:
    static int nextStudentID;
    int studentID;
    date enrollmentDate;
    date graduationDate;

public:
    student();
    student(std::string, date, date);
    student(std::string, date, date, date);
    virtual ~student();

    void setStudentID(int);
    void setEnrollmentDate(date);
    void setGraduationDate(date);

    int getStudentID() const;
    const date& getEnrollmentDate() const;
    const date& getGraduationDate() const;
    bool hasGraduated() const;

    virtual int getid() const;
    virtual bool addCourse(course*) = 0;
    virtual bool dropCourse(course*) = 0;
    virtual void printPerson() const;
};

#endif
