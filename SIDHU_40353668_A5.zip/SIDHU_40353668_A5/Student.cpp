#include "student.h"
#include <iostream>

int student::nextStudentID = 1000;

student::student() : person() {
    nextStudentID++;
    studentID = nextStudentID;
    enrollmentDate = date();
    graduationDate = date(0, 0, 0);
}

student::student(std::string name, date dob, date enrollDate) : person(name, dob) {
    nextStudentID++;
    studentID = nextStudentID;
    enrollmentDate = enrollDate;
    graduationDate = date(0, 0, 0);
}

student::student(std::string name, date dob, date enrollDate, date gradDate) : person(name, dob) {
    nextStudentID++;
    studentID = nextStudentID;
    enrollmentDate = enrollDate;
    graduationDate = gradDate;
}

student::~student() {
    std::cout << "Student has been deleted" << std::endl;
}

void student::setStudentID(int id) {
    studentID = id;
    if (id > nextStudentID) {
        nextStudentID = id;
    }
}

void student::setEnrollmentDate(date enrollDate) {
    enrollmentDate = enrollDate;
}

void student::setGraduationDate(date gradDate) {
    graduationDate = gradDate;
}

int student::getStudentID() const {
    return studentID;
}

const date& student::getEnrollmentDate() const {
    return enrollmentDate;
}

const date& student::getGraduationDate() const {
    return graduationDate;
}

bool student::hasGraduated() const {
    return !(graduationDate.getDay() == 0 && graduationDate.getMonth() == 0 && graduationDate.getYear() == 0);
}

int student::getid() const {
    return studentID;
}

void student::printPerson() const {
    person::printPerson();
    std::cout << "Student ID: " << studentID << std::endl;
    std::cout << "Enrollment Date: " << enrollmentDate << std::endl;
    std::cout << "Graduation Date: " << graduationDate << std::endl;
}
