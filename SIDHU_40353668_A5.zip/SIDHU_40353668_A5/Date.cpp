#include "date.h"
#include <iostream>

// Constructor uses the same order as the original project: day, month, year.
date::date() {
    day = 0;
    month = 0;
    year = 0;
}

date::date(int d, int m, int y) {
    day = d;
    month = m;
    year = y;
}

date::~date() {
    std::cout << " Date Deleted" << std::endl;
}

void date::setMonth(int month) {
    this->month = month;
}

void date::setDay(int day) {
    this->day = day;
}

void date::setYear(int year) {
    this->year = year;
}

int date::getMonth() const {
    return month;
}

int date::getDay() const {
    return day;
}

int date::getYear() const {
    return year;
}

bool date::operator>(const date& other) const {
    if (year > other.year) {
        return true;
    }
    if (year < other.year) {
        return false;
    }
    if (month > other.month) {
        return true;
    }
    if (month < other.month) {
        return false;
    }
    return day > other.day;
}

std::ostream& operator<<(std::ostream& out, const date& d) {
    out << d.day << "/" << d.month << "/" << d.year;
    return out;
}

void date::printDate() const {
    std::cout << *this << std::endl;
}
