#include "undergraduatestudent.h"
#include <iostream>

undergraduatestudent::undergraduatestudent() : student() {
    numCourses = 0;
    for (int i = 0; i < 4; i++) {
        courses[i] = nullptr;
    }
}

undergraduatestudent::undergraduatestudent(std::string name, date dob, date enrollDate)
    : student(name, dob, enrollDate) {
    numCourses = 0;
    for (int i = 0; i < 4; i++) {
        courses[i] = nullptr;
    }
}

undergraduatestudent::undergraduatestudent(std::string name, date dob, date enrollDate, date gradDate)
    : student(name, dob, enrollDate, gradDate) {
    numCourses = 0;
    for (int i = 0; i < 4; i++) {
        courses[i] = nullptr;
    }
}

undergraduatestudent::~undergraduatestudent() {
    std::cout << "UndergraduateStudent has been deleted" << std::endl;
}

int undergraduatestudent::getNumCourses() const {
    return numCourses;
}

bool undergraduatestudent::addCourse(course* newCourse) {
    if (numCourses >= 4 || newCourse == nullptr) {
        return false;
    }

    for (int i = 0; i < numCourses; i++) {
        if (courses[i] != nullptr && courses[i]->isSameCourse(newCourse)) {
            return false;
        }
    }

    courses[numCourses] = newCourse;
    numCourses++;
    return true;
}

bool undergraduatestudent::dropCourse(course* selectedCourse) {
    if (selectedCourse == nullptr) {
        return false;
    }

    for (int i = 0; i < numCourses; i++) {
        if (courses[i] != nullptr && courses[i]->isSameCourse(selectedCourse)) {
            for (int j = i; j < numCourses - 1; j++) {
                courses[j] = courses[j + 1];
            }
            courses[numCourses - 1] = nullptr;
            numCourses--;
            return true;
        }
    }
    return false;
}

void undergraduatestudent::printPerson() const {
    std::cout << *this;
}

std::ostream& operator<<(std::ostream& out, const undergraduatestudent& undergrad) {
    out << "Name: " << undergrad.getName() << std::endl;
    out << "DOB: " << undergrad.getDOB() << std::endl;
    out << "Student ID: " << undergrad.getStudentID() << std::endl;
    out << "Enrollment Date: " << undergrad.getEnrollmentDate() << std::endl;
    out << "Graduation Date: " << undergrad.getGraduationDate() << std::endl;
    out << "Student Type: Undergraduate Student" << std::endl;
    out << "Number of Courses: " << undergrad.numCourses << std::endl;
    out << "Registered Courses:" << std::endl;

    for (int i = 0; i < undergrad.numCourses; i++) {
        if (undergrad.courses[i] != nullptr) {
            out << undergrad.courses[i]->getDepartment() << " "
                << undergrad.courses[i]->getCourseNum() << ": "
                << undergrad.courses[i]->getCourseName() << std::endl;
        }
    }
    return out;
}
