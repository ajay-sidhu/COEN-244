#ifndef PERSON_H
#define PERSON_H

#include <string>
#include "date.h"

class person {
private:
    std::string name;
    date dob;

public:
    person();
    person(std::string, date);
    virtual ~person();

    void setName(std::string);
    void setDOB(date);

    std::string getName() const;
    const date& getDOB() const;

    virtual int getid() const = 0;
    virtual void printPerson() const;
};

#endif
