#ifndef GRADUATESTUDENT_H
#define GRADUATESTUDENT_H

#include "student.h"
#include "course.h"
#include <ostream>
#include <string>

class graduatestudent : public student {
private:
    int numCourses;
    course* courses[2];
    std::string supervisorName;

public:
    graduatestudent();
    graduatestudent(std::string, date, date);
    graduatestudent(std::string, date, date, date, std::string);
    virtual ~graduatestudent();

    void setSupervisorName(std::string);
    int getNumCourses() const;
    std::string getSupervisorName() const;

    virtual bool addCourse(course*);
    virtual bool dropCourse(course*);
    virtual void printPerson() const;

    friend std::ostream& operator<<(std::ostream&, const graduatestudent&);
};

#endif
