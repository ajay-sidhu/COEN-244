#ifndef FULLTIMEPROFESSOR_H
#define FULLTIMEPROFESSOR_H

#include "professor.h"
#include "course.h"
#include "graduatestudent.h"
#include <string>

class fulltimeprofessor : public professor {
private:
    int numCourses;
    course* courses[2];
    int numSupervisedStudents;
    graduatestudent* supervisedStudents[10];

public:
    fulltimeprofessor();
    fulltimeprofessor(std::string, date, date);
    virtual ~fulltimeprofessor();

    int getNumCourses() const;
    int getNumSupervisedStudents() const;

    virtual bool addCourse(course*);
    bool addGraduateStudent(graduatestudent*);
    virtual void printPerson() const;
};

#endif
