#ifndef PARTTIMEPROFESSOR_H
#define PARTTIMEPROFESSOR_H

#include "professor.h"
#include "course.h"
#include <string>

class parttimeprofessor : public professor {
private:
    int numCourses;
    course* courses[3];

public:
    parttimeprofessor();
    parttimeprofessor(std::string, date, date);
    virtual ~parttimeprofessor();

    int getNumCourses() const;
    virtual bool addCourse(course*);
    virtual void printPerson() const;
};

#endif
