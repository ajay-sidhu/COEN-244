#include "course.h"
#include <iostream>
#include <string>

course::course() {
    department = "";
    courseName = "";
    courseNum = 0;
    professorName = "";
}

course::course(std::string depName, int courseID, std::string cName) {
    department = depName;
    courseName = cName;
    courseNum = courseID;
    professorName = "";
}

course::course(std::string depName, int courseID, std::string cName, std::string profName) {
    department = depName;
    courseName = cName;
    courseNum = courseID;
    professorName = profName;
}

course::~course() {
    std::cout << "Course has been deleted" << std::endl;
}

void course::setDepartment(std::string department) {
    this->department = department;
}

void course::setCourseName(std::string courseName) {
    this->courseName = courseName;
}

void course::setCourseNum(int courseNum) {
    this->courseNum = courseNum;
}

void course::setProfessorName(std::string professorName) {
    this->professorName = professorName;
}

std::string course::getDepartment() const {
    return department;
}

std::string course::getCourseName() const {
    return courseName;
}

int course::getCourseNum() const {
    return courseNum;
}

std::string course::getProfessorName() const {
    return professorName;
}

bool course::isSameCourse(const course* other) const {
    if (other == nullptr) {
        return false;
    }
    return department == other->getDepartment() && courseNum == other->getCourseNum();
}

void course::printCourse() const {
    std::cout << "Course: " << department << " " << courseNum << ": " << courseName << std::endl;
    std::cout << "Professor: " << professorName << std::endl;
}
