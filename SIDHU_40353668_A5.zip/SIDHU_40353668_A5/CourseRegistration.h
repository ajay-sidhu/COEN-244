#ifndef COURSEREGISTRATION_H
#define COURSEREGISTRATION_H

#include "course.h"
#include <string>

class courseregistration : public course {
private:
    int maxSize;
    int numStudents;
    int* studentIDs;

public:
    courseregistration();
    courseregistration(std::string, int, std::string, int);
    courseregistration(std::string, int, std::string, std::string, int);
    virtual ~courseregistration();

    void setMaxSize(int);
    void setNumStudents(int); 

    int getMaxSize() const;
    int getNumStudents() const;

    bool registerStudent(int);
    bool removeStudent(int);
    bool isStudentRegistered(int) const;

    virtual void printCourse() const;
    void printCourseRegistration() const;
};

#endif
