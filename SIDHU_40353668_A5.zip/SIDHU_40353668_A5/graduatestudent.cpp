#include "graduatestudent.h"
#include <iostream>

graduatestudent::graduatestudent() : student() {
    numCourses = 0;
    supervisorName = "";
    for (int i = 0; i < 2; i++) {
        courses[i] = nullptr;
    }
}

graduatestudent::graduatestudent(std::string name, date dob, date enrollDate)
    : student(name, dob, enrollDate) {
    numCourses = 0;
    supervisorName = "";
    for (int i = 0; i < 2; i++) {
        courses[i] = nullptr;
    }
}

graduatestudent::graduatestudent(std::string name, date dob, date enrollDate, date gradDate, std::string supervisor)
    : student(name, dob, enrollDate, gradDate) {
    numCourses = 0;
    supervisorName = supervisor;
    for (int i = 0; i < 2; i++) {
        courses[i] = nullptr;
    }
}

graduatestudent::~graduatestudent() {
    std::cout << "GraduateStudent has been deleted" << std::endl;
}

void graduatestudent::setSupervisorName(std::string supervisor) {
    supervisorName = supervisor;
}

int graduatestudent::getNumCourses() const {
    return numCourses;
}

std::string graduatestudent::getSupervisorName() const {
    return supervisorName;
}

bool graduatestudent::addCourse(course* newCourse) {
    if (numCourses >= 2 || newCourse == nullptr) {
        return false;
    }

    for (int i = 0; i < numCourses; i++) {
        if (courses[i] != nullptr && courses[i]->isSameCourse(newCourse)) {
            return false;
        }
    }

    courses[numCourses] = newCourse;
    numCourses++;
    return true;
}

bool graduatestudent::dropCourse(course* selectedCourse) {
    if (selectedCourse == nullptr) {
        return false;
    }

    for (int i = 0; i < numCourses; i++) {
        if (courses[i] != nullptr && courses[i]->isSameCourse(selectedCourse)) {
            for (int j = i; j < numCourses - 1; j++) {
                courses[j] = courses[j + 1];
            }
            courses[numCourses - 1] = nullptr;
            numCourses--;
            return true;
        }
    }
    return false;
}

void graduatestudent::printPerson() const {
    std::cout << *this;
}

std::ostream& operator<<(std::ostream& out, const graduatestudent& grad) {
    out << "Name: " << grad.getName() << std::endl;
    out << "DOB: " << grad.getDOB() << std::endl;
    out << "Student ID: " << grad.getStudentID() << std::endl;
    out << "Enrollment Date: " << grad.getEnrollmentDate() << std::endl;
    out << "Graduation Date: " << grad.getGraduationDate() << std::endl;
    out << "Student Type: Graduate Student" << std::endl;
    out << "Supervisor Name: " << grad.supervisorName << std::endl;
    out << "Number of Courses: " << grad.numCourses << std::endl;
    out << "Registered Courses:" << std::endl;

    for (int i = 0; i < grad.numCourses; i++) {
        if (grad.courses[i] != nullptr) {
            out << grad.courses[i]->getDepartment() << " "
                << grad.courses[i]->getCourseNum() << ": "
                << grad.courses[i]->getCourseName() << std::endl;
        }
    }
    return out;
}
