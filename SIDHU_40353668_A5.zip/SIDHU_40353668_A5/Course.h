#ifndef COURSE_H
#define COURSE_H

#include <string>

class course {
private:
    std::string department;
    std::string courseName;
    int courseNum;
    std::string professorName;

public:
    course();
    course(std::string, int, std::string);
    course(std::string, int, std::string, std::string);
    virtual ~course();

    void setDepartment(std::string);
    void setCourseName(std::string);
    void setCourseNum(int);
    void setProfessorName(std::string);

    std::string getDepartment() const;
    std::string getCourseName() const;
    int getCourseNum() const;
    std::string getProfessorName() const;

    bool isSameCourse(const course*) const;

    virtual void printCourse() const;
};

#endif
