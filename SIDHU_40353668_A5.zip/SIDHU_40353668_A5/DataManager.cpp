#include "datamanager.h"
#include "undergraduatestudent.h"
#include "graduatestudent.h"
#include "fulltimeprofessor.h"
#include <algorithm>
#include <cctype>
#include <fstream>
#include <iostream>
#include <stdexcept>

namespace {

    std::string makeFileString(std::string value) {
        for (int i = 0; i < static_cast<int>(value.length()); i++) {
            if (value[i] == ' ') {
                value[i] = '_';
            }
        }
        return value;
    }

    std::string makeReadableString(std::string value) {
        for (int i = 0; i < static_cast<int>(value.length()); i++) {
            if (value[i] == '_') {
                value[i] = ' ';
            }
        }
        return value;
    }

    std::string normalizeClassName(std::string value) {
        std::transform(value.begin(), value.end(), value.begin(),
                       [](unsigned char ch) { return static_cast<char>(std::tolower(ch)); });

        if (value == "undergraduate" || value == "undergraduatestudent") {
            return "undergraduate";
        }
        if (value == "graduate" || value == "graduatestudent") {
            return "graduate";
        }
        return value;
    }

    void displayGraduationStatus(const student& foundStudent, int expectedYears) {
        date actualGraduation = foundStudent.getGraduationDate();

        if (!foundStudent.hasGraduated()) {
            std::cout << "Student has not graduated yet." << std::endl;
            return;
        }

        date enrollment = foundStudent.getEnrollmentDate();
        date expectedGraduation(enrollment.getDay(), enrollment.getMonth(), enrollment.getYear() + expectedYears);

        std::cout << "Expected Graduation Date: " << expectedGraduation << std::endl;

        if (actualGraduation > expectedGraduation) {
            std::cout << "Student did not graduate on time." << std::endl;
        }
        else {
            std::cout << "Student graduated on time." << std::endl;
        }
    }
}

datamanager::datamanager() {
    numStudents = 0;
    numProfessors = 0;
    numCourses = 0;

    for (int i = 0; i < 5000; i++) {
        students[i] = nullptr;
    }
    for (int i = 0; i < 100; i++) {
        professors[i] = nullptr;
    }
    for (int i = 0; i < 200; i++) {
        courses[i] = nullptr;
    }
}

datamanager::~datamanager() {
    for (int i = 0; i < numStudents; i++) {
        delete students[i];
        students[i] = nullptr;
    }
    for (int i = 0; i < numProfessors; i++) {
        delete professors[i];
        professors[i] = nullptr;
    }
    for (int i = 0; i < numCourses; i++) {
        delete courses[i];
        courses[i] = nullptr;
    }

    std::cout << "DataManager has been deleted" << std::endl;
}

student* datamanager::findStudent(int studentID) const {
    for (int i = 0; i < numStudents; i++) {
        if (students[i] != nullptr && students[i]->getid() == studentID) {
            return students[i];
        }
    }
    return nullptr;
}

professor* datamanager::findProfessor(int employeeID) const {
    for (int i = 0; i < numProfessors; i++) {
        if (professors[i] != nullptr && professors[i]->getid() == employeeID) {
            return professors[i];
        }
    }
    return nullptr;
}

courseregistration* datamanager::findCourse(const courseregistration* selectedCourse) const {
    if (selectedCourse == nullptr) {
        return nullptr;
    }

    for (int i = 0; i < numCourses; i++) {
        if (courses[i] != nullptr && courses[i]->isSameCourse(selectedCourse)) {
            return courses[i];
        }
    }
    return nullptr;
}

bool datamanager::addStudent(student* newStudent) {
    if (numStudents >= 5000 || newStudent == nullptr) {
        return false;
    }

    students[numStudents] = newStudent;
    numStudents++;
    std::cout << "Student " << newStudent->getid() << " enrolled at university." << std::endl;
    return true;
}

bool datamanager::addProfessor(professor* newProfessor) {
    if (numProfessors >= 100 || newProfessor == nullptr) {
        return false;
    }

    professors[numProfessors] = newProfessor;
    numProfessors++;
    std::cout << "Professor " << newProfessor->getid() << " added to university." << std::endl;
    return true;
}

bool datamanager::addCourse(courseregistration* newCourse) {
    if (numCourses >= 200 || newCourse == nullptr) {
        return false;
    }

    if (findCourse(newCourse) != nullptr) {
        return false;
    }

    courses[numCourses] = newCourse;
    numCourses++;
    std::cout << newCourse->getDepartment() << " " << newCourse->getCourseNum() << " added." << std::endl;
    return true;
}

bool datamanager::removeStudent(int studentID) {
    for (int i = 0; i < numStudents; i++) {
        if (students[i] != nullptr && students[i]->getid() == studentID) {
            delete students[i];

            for (int j = i; j < numStudents - 1; j++) {
                students[j] = students[j + 1];
            }
            students[numStudents - 1] = nullptr;
            numStudents--;
            std::cout << "Student " << studentID << " removed from university." << std::endl;
            return true;
        }
    }
    return false;
}

bool datamanager::removeCourse(courseregistration* selectedCourse) {
    for (int i = 0; i < numCourses; i++) {
        if (courses[i] != nullptr && courses[i]->isSameCourse(selectedCourse)) {
            std::string department = courses[i]->getDepartment();
            int courseNumber = courses[i]->getCourseNum();
            delete courses[i];

            for (int j = i; j < numCourses - 1; j++) {
                courses[j] = courses[j + 1];
            }
            courses[numCourses - 1] = nullptr;
            numCourses--;
            std::cout << department << " " << courseNumber << " removed from course list." << std::endl;
            return true;
        }
    }
    return false;
}

bool datamanager::registerStudentToCourse(int studentID, courseregistration* selectedCourse) {
    student* selectedStudent = findStudent(studentID);
    courseregistration* storedCourse = findCourse(selectedCourse);

    if (selectedStudent == nullptr || storedCourse == nullptr) {
        return false;
    }

    if (!storedCourse->registerStudent(studentID)) {
        return false;
    }

    if (!selectedStudent->addCourse(storedCourse)) {
        storedCourse->removeStudent(studentID);
        return false;
    }

    std::cout << "Student " << studentID << " registered to "
              << storedCourse->getDepartment() << " " << storedCourse->getCourseNum() << "." << std::endl;
    return true;
}

bool datamanager::dropStudentFromCourse(int studentID, courseregistration* selectedCourse) {
    student* selectedStudent = findStudent(studentID);
    courseregistration* storedCourse = findCourse(selectedCourse);

    if (selectedStudent == nullptr || storedCourse == nullptr) {
        return false;
    }

    bool removedFromCourse = storedCourse->removeStudent(studentID);
    bool removedFromStudent = selectedStudent->dropCourse(storedCourse);

    if (removedFromCourse && removedFromStudent) {
        std::cout << "Student " << studentID << " dropped "
                  << storedCourse->getDepartment() << " " << storedCourse->getCourseNum() << "." << std::endl;
        return true;
    }

    return false;
}

bool datamanager::isStudentEnrolled(int studentID, courseregistration* selectedCourse) const {
    courseregistration* storedCourse = findCourse(selectedCourse);
    if (storedCourse == nullptr) {
        return false;
    }

    return storedCourse->isStudentRegistered(studentID);
}

bool datamanager::isStudentAtUniversity(int studentID) const {
    return findStudent(studentID) != nullptr;
}

bool datamanager::addSupervisor(int gradStudentID, int professorID) {
    student* selectedStudent = findStudent(gradStudentID);
    professor* selectedProfessor = findProfessor(professorID);

    graduatestudent* grad = dynamic_cast<graduatestudent*>(selectedStudent);
    fulltimeprofessor* fullTime = dynamic_cast<fulltimeprofessor*>(selectedProfessor);

    if (grad == nullptr || fullTime == nullptr) {
        return false;
    }

    if (fullTime->addGraduateStudent(grad)) {
        grad->setSupervisorName(fullTime->getName());
        std::cout << "Professor " << professorID << " is now supervising graduate student "
                  << gradStudentID << "." << std::endl;
        return true;
    }

    return false;
}

bool datamanager::saveStudent(std::string studentFile, student* selectedStudent) {
    if (selectedStudent == nullptr) {
        return false;
    }

    std::ofstream output(studentFile.c_str(), std::ios::app);
    if (!output) {
        throw std::runtime_error("File cannot be opened");
    }

    std::string className;
    graduatestudent* grad = dynamic_cast<graduatestudent*>(selectedStudent);
    undergraduatestudent* undergrad = dynamic_cast<undergraduatestudent*>(selectedStudent);

    if (grad != nullptr) {
        className = "graduate";
    }
    else if (undergrad != nullptr) {
        className = "undergraduate";
    }
    else {
        return false;
    }

    date dob = selectedStudent->getDOB();
    date enrollment = selectedStudent->getEnrollmentDate();
    date graduation = selectedStudent->getGraduationDate();

    output << className << " "
           << selectedStudent->getStudentID() << " "
           << makeFileString(selectedStudent->getName()) << " "
           << dob.getMonth() << " " << dob.getDay() << " " << dob.getYear() << " "
           << enrollment.getMonth() << " " << enrollment.getDay() << " " << enrollment.getYear() << " "
           << graduation.getMonth() << " " << graduation.getDay() << " " << graduation.getYear();

    if (grad != nullptr) {
        output << " " << makeFileString(grad->getSupervisorName());
    }

    output << std::endl;
    return true;
}

void datamanager::searchStudent(std::string studentFile, std::string className, int student_id) {
    std::ifstream input(studentFile.c_str());
    if (!input) {
        throw std::runtime_error("File cannot be opened");
    }

    std::string wantedClass = normalizeClassName(className);
    std::string fileClassName;

    while (input >> fileClassName) {
        int fileStudentID;
        std::string name;
        int birthMonth, birthDay, birthYear;
        int enrollmentMonth, enrollmentDay, enrollmentYear;
        int graduationMonth, graduationDay, graduationYear;
        std::string supervisor;

        input >> fileStudentID >> name
              >> birthMonth >> birthDay >> birthYear
              >> enrollmentMonth >> enrollmentDay >> enrollmentYear
              >> graduationMonth >> graduationDay >> graduationYear;

        std::string normalizedFileClass = normalizeClassName(fileClassName);
        if (normalizedFileClass == "graduate") {
            input >> supervisor;
        }

        if (!input) {
            break;
        }

        if (normalizedFileClass == wantedClass && fileStudentID == student_id) {
            name = makeReadableString(name);
            supervisor = makeReadableString(supervisor);

            date dob(birthDay, birthMonth, birthYear);
            date enrollment(enrollmentDay, enrollmentMonth, enrollmentYear);
            date graduation(graduationDay, graduationMonth, graduationYear);

            if (wantedClass == "undergraduate") {
                undergraduatestudent* foundStudent = new undergraduatestudent(name, dob, enrollment, graduation);
                foundStudent->setStudentID(fileStudentID);
                std::cout << *foundStudent;
                displayGraduationStatus(*foundStudent, 4);
                delete foundStudent;
                return;
            }
            if (wantedClass == "graduate") {
                graduatestudent* foundStudent = new graduatestudent(name, dob, enrollment, graduation, supervisor);
                foundStudent->setStudentID(fileStudentID);
                std::cout << *foundStudent;
                displayGraduationStatus(*foundStudent, 2);
                delete foundStudent;
                return;
            }
        }
    }

    throw std::runtime_error("Student couldnot be found");
}

void datamanager::printStudents() const {
    std::cout << "\n--- Students ---" << std::endl;
    for (int i = 0; i < numStudents; i++) {
        if (students[i] != nullptr) {
            students[i]->printPerson();
            std::cout << std::endl;
        }
    }
}

void datamanager::printProfessors() const {
    std::cout << "\n--- Professors ---" << std::endl;
    for (int i = 0; i < numProfessors; i++) {
        if (professors[i] != nullptr) {
            professors[i]->printPerson();
            std::cout << std::endl;
        }
    }
}

void datamanager::printCourses() const {
    std::cout << "\n--- Courses ---" << std::endl;
    for (int i = 0; i < numCourses; i++) {
        if (courses[i] != nullptr) {
            courses[i]->printCourseRegistration();
            std::cout << std::endl;
        }
    }
}
