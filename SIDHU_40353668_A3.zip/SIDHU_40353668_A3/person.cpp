#include "person.h"
#include <iostream>

//constructors/destructors
person::person(){
    name = "";
}
person::person(std::string n, date d){
    name = n;
    dob = d;
}
person::~person(){
    std::cout<<"Person was Deleted"<<std::endl;
}

//setters
void person::setName(std::string name){
    this->name = name;
}
void person::setDOB(date dob){
    this->dob = dob;
}

//getters
std::string person::getName() const{
    return name;
}
date person::getDOB() const{
    return dob;
}

//print
void person::printPerson() const{
    std::cout<<"Name: "<<name<<std::endl;
    std::cout<<"DOB: ";
    dob.printDate();
}

