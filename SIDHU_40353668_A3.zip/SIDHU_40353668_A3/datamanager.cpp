#include "datamanager.h"
#include <iostream>

// constructor/destructor
datamanager::datamanager(){
    numStudents = 0;
    numCourses = 0;

    for (int i = 0; i < 5000; i++) {
        students[i] = nullptr;
    }

    for (int i = 0; i < 200; i++) {
        courses[i] = nullptr;
    }
}

datamanager::~datamanager(){
    for (int i = 0; i < numStudents; i++) {
        delete students[i];
        students[i] = nullptr;
    }

    for (int i = 0; i < numCourses; i++) {
        delete courses[i];
        courses[i] = nullptr;
    }

    std::cout << "DataManager has been deleted" << std::endl;
}

// enroll student at university
bool datamanager::enrollStudent(student* newStudent){
    if (numStudents >= 5000) {
        return false;
    }

    if (isStudentEnrolled(newStudent->getStudentID())) {
        return false;
    }

    students[numStudents] = newStudent;
    numStudents++;

    return true;
}

// remove student from university
bool datamanager::removeStudent(int studentID){
    for (int i = 0; i < numStudents; i++) {
        if (students[i] != nullptr && students[i]->getStudentID() == studentID) {

            // remove student from all courses first
            for (int c = 0; c < numCourses; c++) {
                if (courses[c] != nullptr) {
                    courses[c]->removeStudent(studentID);
                }
            }

            delete students[i];

            for (int j = i; j < numStudents - 1; j++) {
                students[j] = students[j + 1];
            }

            students[numStudents - 1] = nullptr;
            numStudents--;

            return true;
        }
    }

    return false;
}

// check if student is enrolled at university
bool datamanager::isStudentEnrolled(int studentID) const{
    for (int i = 0; i < numStudents; i++) {
        if (students[i] != nullptr && students[i]->getStudentID() == studentID) {
            return true;
        }
    }

    return false;
}

// add new course
bool datamanager::addCourse(courseregistration* newCourse){
    if (numCourses >= 200) {
        return false;
    }

    if (findCourse(newCourse->getCourseNum()) != nullptr) {
        return false;
    }

    courses[numCourses] = newCourse;
    numCourses++;

    return true;
}

// remove course
bool datamanager::removeCourse(int courseNum){
    for (int i = 0; i < numCourses; i++) {
        if (courses[i] != nullptr && courses[i]->getCourseNum() == courseNum) {

            // remove this course from every student's course list
            for (int s = 0; s < numStudents; s++) {
                if (students[s] != nullptr) {
                    students[s]->dropCourse(courseNum);
                }
            }

            delete courses[i];

            for (int j = i; j < numCourses - 1; j++) {
                courses[j] = courses[j + 1];
            }

            courses[numCourses - 1] = nullptr;
            numCourses--;

            return true;
        }
    }

    return false;
}

// register student to course
bool datamanager::registerStudentToCourse(int studentID, int courseNum){
    student* foundStudent = findStudent(studentID);
    courseregistration* foundCourse = findCourse(courseNum);

    if (foundStudent == nullptr || foundCourse == nullptr) {
        return false;
    }

    if (foundStudent->getNumCourses() >= 4) {
        return false;
    }

    if (foundCourse->isStudentRegistered(studentID)) {
        return false;
    }

    bool addedToStudent = foundStudent->addCourse(foundCourse);
    bool addedToCourse = foundCourse->registerStudent(studentID);

    if (addedToStudent && addedToCourse) {
        return true;
    }

    return false;
}

// drop student from course
bool datamanager::dropStudentFromCourse(int studentID, int courseNum){
    student* foundStudent = findStudent(studentID);
    courseregistration* foundCourse = findCourse(courseNum);

    if (foundStudent == nullptr || foundCourse == nullptr) {
        return false;
    }

    bool removedFromStudent = foundStudent->dropCourse(courseNum);
    bool removedFromCourse = foundCourse->removeStudent(studentID);

    if (removedFromStudent && removedFromCourse) {
        return true;
    }

    return false;
}

// check if student is in a course
bool datamanager::isStudentInCourse(int studentID, int courseNum) const{
    courseregistration* foundCourse = findCourse(courseNum);

    if (foundCourse == nullptr) {
        return false;
    }

    return foundCourse->isStudentRegistered(studentID);
}

// find student by ID
student* datamanager::findStudent(int studentID) const{
    for (int i = 0; i < numStudents; i++) {
        if (students[i] != nullptr && students[i]->getStudentID() == studentID) {
            return students[i];
        }
    }

    return nullptr;
}

// find course by course number
courseregistration* datamanager::findCourse(int courseNum) const{
    for (int i = 0; i < numCourses; i++) {
        if (courses[i] != nullptr && courses[i]->getCourseNum() == courseNum) {
            return courses[i];
        }
    }

    return nullptr;
}