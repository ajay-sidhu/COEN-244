#include "date.h"
#include <iostream>

//constructors/destructor
date::date(){
    day = 0;
    month = 0;
    year = 0;
}
date::date(int d, int m,int y){
    day = d;
    month = m;
    year = y;
}
date::~date(){
    std::cout<<" Date Deleted"<<std::endl;
}

//setters
void date::setMonth(int month){
    this->month = month;
}
void date::setDay(int day){
    this->day = day;
}
void date::setYear(int year){
    this->year = year;
}

//getters
int date::getMonth() const{
    return month;
} 
int date::getDay() const{
    return day;
}
int date::getYear() const{
    return year;
}

//print Date
void date::printDate() const{
    std::cout<<day<<"/"<<month<<"/"<<year<<std::endl;
} 

