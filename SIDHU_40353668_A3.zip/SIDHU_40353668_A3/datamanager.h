#ifndef DATAMANAGER_H
#define DATAMANAGER_H

#include "student.h"
#include "courseregistration.h"

class datamanager {
private:
    int numStudents;
    int numCourses;

    student* students[5000];
    courseregistration* courses[200];

public:
    // constructor/destructor
    datamanager();
    ~datamanager();

    // student functions
    bool enrollStudent(student*);
    bool removeStudent(int);
    bool isStudentEnrolled(int) const;

    // course functions
    bool addCourse(courseregistration*);
    bool removeCourse(int);

    // registration functions
    bool registerStudentToCourse(int, int);
    bool dropStudentFromCourse(int, int);
    bool isStudentInCourse(int, int) const;

    // search functions
    student* findStudent(int) const;
    courseregistration* findCourse(int) const;
};

#endif