#ifndef COURSEREGISTRATION_H
#define COURSEREGISTRATION_H

#include "course.h"

class courseregistration : public course {
private:
    int maxSize;
    int numStudents;
    int* studentIDs;

public:
    // constructors/destructor
    courseregistration();
    courseregistration(std::string, int, std::string, int);
    ~courseregistration();

    // setters
    void setMaxSize(int);
    void setNumStudents(int);

    // getters
    int getMaxSize() const;
    int getNumStudents() const;

    // register/remove student functions
    bool registerStudent(int);
    bool removeStudent(int);

    // helper function
    bool isStudentRegistered(int) const;

    // print function
    void printCourseRegistration() const;
};

#endif