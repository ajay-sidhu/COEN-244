#ifndef PERSON_H
#define PERSON_H

#include<string>
#include "date.h"

class person{
    private:
        std::string name;
        date dob;

    public:
        person();
        person(std::string, date);
        ~person();

        void setName(std::string);
        void setDOB(date);

        std::string getName() const;
        date getDOB() const;

        void printPerson() const;

};

#endif