#ifndef STUDENT_H
#define STUDENT_H

#include "person.h"
#include "course.h"
#include "date.h"


class student : public person{
    private:
        int studentID, numCourses;
        date enrollmentDate;
        course *courses[4];

    public:
        student();
        student(std::string, date, int, date);
        ~student();

        //setters
        void setStudentID(int);
        void setEnrollmentDate(date);
        void setNumCourses(int);

        //getters
        int getStudentID() const;
        date getEnrollmentDate() const;
        int getNumCourses() const;

        // Add/Drop functions
        bool addCourse(course*);
        bool dropCourse(int);

        //Print function
        void printStudent() const;
};
        


#endif
