#ifndef COURSE_H
#define COURSE_H

#include <string>

class course{

    private:
        std::string department;
        std::string courseName;
        int courseNum;

    public:
        course();
        course(std::string, int, std::string);
        ~course();

        void setDepartment(std::string);    
        void setCourseName(std::string);
        void setCourseNum(int);

        std::string getDepartment() const;
        std::string getCourseName() const;
        int getCourseNum() const;

        void printCourse() const;

};

#endif