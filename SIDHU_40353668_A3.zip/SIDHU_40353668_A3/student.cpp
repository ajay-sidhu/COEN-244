#include "student.h"
#include <iostream>

// constructors/destructor
student::student() : person(){
    studentID = 0;
    numCourses = 0;
    enrollmentDate = date();

    for (int i = 0; i < 4; i++) {
        courses[i] = nullptr;
    }
}

student::student(std::string name, date dob, int id, date enrollDate) : person(name, dob){
    studentID = id;
    enrollmentDate = enrollDate;
    numCourses = 0;

    for (int i = 0; i < 4; i++) {
        courses[i] = nullptr;
    }
}

student::~student(){
    std::cout << "Student has been deleted" << std::endl;
}

// setters
void student::setStudentID(int id){
    studentID = id;
}

void student::setEnrollmentDate(date enrollDate){
    enrollmentDate = enrollDate;
}

void student::setNumCourses(int num){
    numCourses = num;
}

// getters
int student::getStudentID() const{
    return studentID;
}

date student::getEnrollmentDate() const{
    return enrollmentDate;
}

int student::getNumCourses() const{
    return numCourses;
}

// add course
bool student::addCourse(course* newCourse){
    if (numCourses >= 4) {
        return false;
    }

    courses[numCourses] = newCourse;
    numCourses++;

    return true;
}

// drop course
bool student::dropCourse(int courseNum){
    for (int i = 0; i < numCourses; i++) {
        if (courses[i] != nullptr && courses[i]->getCourseNum() == courseNum) {

            for (int j = i; j < numCourses - 1; j++) {
                courses[j] = courses[j + 1];
            }

            courses[numCourses - 1] = nullptr;
            numCourses--;

            return true;
        }
    }

    return false;
}

// print function
void student::printStudent() const{
    printPerson();

    std::cout << "Student ID: " << studentID << std::endl;

    std::cout << "Enrollment Date: ";
    enrollmentDate.printDate();

    std::cout << "Number of Courses: " << numCourses << std::endl;

    std::cout << "Registered Courses:" << std::endl;

    for (int i = 0; i < numCourses; i++) {
        if (courses[i] != nullptr) {
            courses[i]->printCourse();
        }
    }
}

