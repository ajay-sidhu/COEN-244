#include "course.h"
#include <iostream>
#include <string>

//constructors and destructor
course::course(){
    department = "";
    courseName= "";
    courseNum = 0;
    
}
course::course(std::string depName, int courseID, std::string cName){
    department = depName;
    courseName= cName;
    courseNum = courseID;
}
course::~course(){
    std::cout<<"Course has been deleted"<<std::endl;
}

//setters
void course::setDepartment(std::string department){
    this->department = department;
}
void course::setCourseName(std::string courseName){
    this->courseName = courseName;
}
void course::setCourseNum(int courseNum){
    this->courseNum = courseNum;
}


//getters
std::string course::getDepartment() const{
    return department;
}
std::string course::getCourseName() const{
    return courseName;
}
int course::getCourseNum() const{
    return courseNum;
}

void course::printCourse() const{
    std::cout<<"Course: "<<department<<" "<<courseNum<<": "<<courseName<<std::endl;
}
