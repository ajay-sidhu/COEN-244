#ifndef DATE_H
#define DATE_H

class date{
private:
int month, day, year;

public:
date();                           
date(int, int ,int);
~date();

//setters
void setMonth(int);                 
void setDay(int);
void setYear(int);

//getters
int getMonth() const;               
int getDay() const;
int getYear() const;

//print Date
void printDate() const;             

};

#endif







