#include "courseregistration.h"
#include <iostream>

// constructors/destructor
courseregistration::courseregistration() : course(){
    maxSize = 0;
    numStudents = 0;
    studentIDs = nullptr;
}

courseregistration::courseregistration(std::string depName, int courseID, std::string cName, int max)
    : course(depName, courseID, cName){
    maxSize = max;
    numStudents = 0;

    studentIDs = new int[maxSize];

    for (int i = 0; i < maxSize; i++) {
        studentIDs[i] = 0;
    }
}

courseregistration::~courseregistration(){
    delete[] studentIDs;
    studentIDs = nullptr;

    std::cout << "CourseRegistration has been deleted" << std::endl;
}

// setters
void courseregistration::setMaxSize(int max){
    maxSize = max;
}

void courseregistration::setNumStudents(int num){
    numStudents = num;
}

// getters
int courseregistration::getMaxSize() const{
    return maxSize;
}

int courseregistration::getNumStudents() const{
    return numStudents;
}

// check if student is already registered
bool courseregistration::isStudentRegistered(int studentID) const{
    for (int i = 0; i < numStudents; i++) {
        if (studentIDs[i] == studentID) {
            return true;
        }
    }

    return false;
}

// register student
bool courseregistration::registerStudent(int studentID){
    if (numStudents >= maxSize) {
        return false;
    }

    if (isStudentRegistered(studentID)) {
        return false;
    }

    studentIDs[numStudents] = studentID;
    numStudents++;

    return true;
}

// remove student
bool courseregistration::removeStudent(int studentID){
    for (int i = 0; i < numStudents; i++) {
        if (studentIDs[i] == studentID) {

            for (int j = i; j < numStudents - 1; j++) {
                studentIDs[j] = studentIDs[j + 1];
            }

            studentIDs[numStudents - 1] = 0;
            numStudents--;

            return true;
        }
    }

    return false;
}

// print function
void courseregistration::printCourseRegistration() const{
    printCourse();

    std::cout << "Maximum Enrollment: " << maxSize << std::endl;
    std::cout << "Number of Students Enrolled: " << numStudents << std::endl;

    std::cout << "Student IDs: ";

    for (int i = 0; i < numStudents; i++) {
        std::cout << studentIDs[i] << " ";
    }

    std::cout << std::endl;
}
