#include <iostream>
#include "datamanager.h"

int main()
{
    // Create DataManager object
    datamanager manager;

    // Create dates
    date dob1(15, 3, 2005);
    date dob2(22, 7, 2004);
    date enrollDate1(1, 9, 2026);
    date enrollDate2(1, 9, 2026);

    // Create students dynamically
    student* s1 = new student("John Smith", dob1, 1001, enrollDate1);
    student* s2 = new student("Mary Brown", dob2, 1002, enrollDate2);

    // Enroll students at university
    if (manager.enrollStudent(s1)) {
        std::cout << "Student 1001 enrolled at university." << std::endl;
    }

    if (manager.enrollStudent(s2)) {
        std::cout << "Student 1002 enrolled at university." << std::endl;
    }

    std::cout << std::endl;

    // Create courses dynamically
    courseregistration* c1 = new courseregistration("COEN", 244, "Programming Methodology", 2);
    courseregistration* c2 = new courseregistration("MATH", 204, "Linear Algebra", 2);
    courseregistration* c3 = new courseregistration("ELEC", 242, "Circuit Analysis", 1);

    // Add courses to DataManager
    if (manager.addCourse(c1)) {
        std::cout << "COEN 244 added." << std::endl;
    }

    if (manager.addCourse(c2)) {
        std::cout << "MATH 204 added." << std::endl;
    }

    if (manager.addCourse(c3)) {
        std::cout << "ELEC 242 added." << std::endl;
    }

    std::cout << std::endl;

    // Register students to courses
    if (manager.registerStudentToCourse(1001, 244)) {
        std::cout << "Student 1001 registered to COEN 244." << std::endl;
    }

    if (manager.registerStudentToCourse(1001, 204)) {
        std::cout << "Student 1001 registered to MATH 204." << std::endl;
    }

    if (manager.registerStudentToCourse(1002, 244)) {
        std::cout << "Student 1002 registered to COEN 244." << std::endl;
    }

    std::cout << std::endl;

    // Try to register student 1002 to ELEC 242
    if (manager.registerStudentToCourse(1002, 242)) {
        std::cout << "Student 1002 registered to ELEC 242." << std::endl;
    } else {
        std::cout << "Could not register Student 1002 to ELEC 242." << std::endl;
    }

    std::cout << std::endl;

    // Check if student is in course
    if (manager.isStudentInCourse(1001, 244)) {
        std::cout << "Student 1001 is enrolled in COEN 244." << std::endl;
    } else {
        std::cout << "Student 1001 is not enrolled in COEN 244." << std::endl;
    }

    std::cout << std::endl;

    // Drop student from course
    if (manager.dropStudentFromCourse(1001, 204)) {
        std::cout << "Student 1001 dropped MATH 204." << std::endl;
    }

    std::cout << std::endl;

    // Remove a student from university
    if (manager.removeStudent(1002)) {
        std::cout << "Student 1002 removed from university." << std::endl;
    }

    std::cout << std::endl;

    // Remove a course
    if (manager.removeCourse(244)) {
        std::cout << "COEN 244 removed from course list." << std::endl;
    }

    std::cout << std::endl;

    // No need to manually delete s1, s2, c1, c2, c3
    // DataManager destructor will delete remaining dynamic objects.

    return 0;
}